# راهنمای اعمال تغییرات بخش ویدیوها روی پروژه `school-app`

این بسته شامل فایل‌های کامل بک‌اند و فرانت‌اند برای پیاده‌سازی و تکمیل بخش **ویدیوها** در پنل معلم و پنل دانش‌آموز است.

## لیست فایل‌های داخل این بسته

### بک‌اند (`backend/`)
1. `backend/src/database/migrations/026_enhance_videos_folders_classes_sharing.js`
   - افزودن ستون‌های `grade`، `target_class_ids` و `quality_variants` به جداول `video_folders` و `videos`.
   - ایجاد جداول رابط `video_folder_classes`، `video_classes`، `video_folder_items` (اشتراک یک ویدیو در چند پوشه) و `video_pdfs` (چند فایل PDF زیر هر ویدیو).
   - انتقال خودکار داده‌های قبلی به جداول جدید بدون از دست رفتن اطلاعات.
2. `backend/src/utils/videoAccessHelper.js`
   - کنترل دقیق نمایش پوشه‌ها و ویدیوها در پنل دانش‌آموز بر اساس کلاس‌های ثبت‌شده در دیتابیس (`class_members` و `classes`).
3. `backend/src/modules/videos/video.routes.js`
   - `GET /api/v1/videos/classes-options`: دریافت لیست کلاس‌ها و پایه‌های ثبت‌شده در دیتابیس برای انتخاب معلم هنگام ساخت پوشه یا انتشار ویدیو.
   - `GET/POST/PUT/DELETE /api/v1/videos/folders`: ساخت، ویرایش (نام، رنگ، پایه و چند کلاس دیتابیس) و حذف پوشه.
   - `GET/POST/DELETE /api/v1/videos`: انتشار ویدیو متصل به کلاس‌های دیتابیس، چند پوشه و چند PDF + تبدیل پس‌زمینه چندکیفیتی (`720p/480p/360p` در صورت نصب `ffmpeg` روی سرور).
   - `GET /api/v1/videos/:id/stream?quality=...`: استریم ویدیو با پشتیبانی `Range` و انتخاب کیفیت.
   - `GET /api/v1/videos/:id/download`: دانلود مستقیم ویدیو با هدر `Content-Disposition: attachment` برای معلم و دانش‌آموز.
   - `PATCH /api/v1/videos/:id/folder` و `PUT /api/v1/videos/:id/folders`: انتقال بین پوشه‌ها و اشتراک هم‌زمان یک ویدیو در چند پوشه.
   - `PUT /api/v1/videos/:id/classes`: ویرایش کلاس‌های مجاز هر ویدیو.
   - `POST/GET/DELETE /api/v1/videos/:id/pdf...`: افزودن، مشاهده آنلاین، دانلود و حذف فایل‌های PDF زیر ویدیو.

### فرانت‌اند (`frontend/`)
1. `frontend/src/components/videos/VideoPlayerModal.js`
   - پلیر با تنظیم سرعت (`0.5x` تا `2x`)، انتخاب کیفیت (با حفظ لحظه پخش)، دکمه اختصاصی تمام‌صفحه (و کلید `F`)، دکمه دانلود ویدیو و بخش **فایل‌های PDF در پایین ویدیو** (با پیش‌نمایش آنلاین `iframe`، دانلود و افزودن/حذف برای معلم).
2. `frontend/src/components/videos/FolderModal.js`
   - ساخت و ویرایش پوشه با انتخاب پایه و کلاس‌های ثبت‌شده در دیتابیس.
3. `frontend/src/components/videos/UploadVideoModal.js`
   - آپلود ویدیو داخل یک یا چند پوشه با انتخاب کلاس‌های دیتابیس و پیوست چند فایل PDF.
4. `frontend/src/components/videos/MoveShareModal.js`
   - مودال سه‌تب برای انتقال بین پوشه‌ها، اشتراک یک ویدیو در چند پوشه و تغییر کلاس‌های مجاز.
5. `frontend/src/app/dashboard/videos/page.js` و `frontend/src/app/dashboard/videos/videos.module.css`
   - صفحه یکپارچه پنل معلم و دانش‌آموز با دکمه `+` روی هر پوشه و کارت `+` افزودن ویدیو.

## مراحل نصب و اجرا

1. فایل ZIP را در ریشه مخزن `school-app` استخراج (Extract / Replace) کنید تا فایل‌ها دقیقاً در مسیرهای `backend/...` و `frontend/...` جایگزین شوند.
2. در پوشه `backend` مایگریشن دیتابیس را اجرا کنید (یا سرور را ری‌استارت کنید چون `ensureDatabaseReady()` مایگریشن‌ها را خودکار اجرا می‌کند):
   ```bash
   cd backend
   npx knex migrate:latest
   ```
3. (اختیاری برای کیفیت‌های متعدد `720p/480p/360p`): اگر `ffmpeg` روی سرور نصب باشد، هنگام آپلود ویدیو نسخه‌های کم‌حجم‌تر به صورت خودکار در پس‌زمینه ساخته می‌شوند؛ بدون `ffmpeg` نیز کیفیت اصلی بدون خطا پخش می‌شود.
4. تغییرات را در گیت کامیت و پوش کنید:
   ```bash
   git status
   git add .
   git commit -m "feat(videos): add DB class targeting, folder sharing, multi-PDF viewer, download, and player controls"
   git push origin main
   ```
